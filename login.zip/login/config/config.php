<?php
$bot_token = "TEST_BOT_63876739793"; /* bot token */
$chat_id = ""; /* chatid */

?>